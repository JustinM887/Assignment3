    /*jshint esversion: 6 */
    const images = ['cherry.png', 'grapes.png', 'heart.png', 'lemon.png', 'orange.png', 'seven.png', 'strawberry.png'];

    // Set an event listener for the button and execute a function that changes images' src attribute to change images
    $('#Spin').click(changeImage);
    function changeImage() {

        $('img').each(function (index, element) {
            $(element).attr("src", "img/"+ images[generateRandom()]);
        });
    }

    function generateRandom() {
        return Math.floor(Math.random() * images.length);
    }

    let money = 1;

        // Sets event listener for plus button and executes a function where amount is incremented by 1
        $('#plus-button').click(function () {
                $('#money').text(++money);
            }
        );

        // Sets event listener for minus button and executes a function where amount is decremented by 1
        $('#minus-button').click(decrement);
        function decrement() {
            if (money > 1){
                $('#money').text(--money);
            }
        }

    function showMessage()
    {
      const msg = document.getElementById("message");
      msg.style.display = "block";
      msg.classList.add('animated', 'pulse');
    }

    function hideMessage()
    {
      const msg = document.getElementById("message");
      msg.style.display = "none";
    }

    let betAmount = 50;

    if (slot1 === slot2 && slot1 === slot3)
    {
      $('#betAmount').text(15*betAmount);
      showMessage();
    }
    else
    {
      $('#betAmount').text(betAmount-betAmount);
      hideMessage();
    }
